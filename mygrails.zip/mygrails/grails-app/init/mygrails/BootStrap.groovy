package mygrails

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
